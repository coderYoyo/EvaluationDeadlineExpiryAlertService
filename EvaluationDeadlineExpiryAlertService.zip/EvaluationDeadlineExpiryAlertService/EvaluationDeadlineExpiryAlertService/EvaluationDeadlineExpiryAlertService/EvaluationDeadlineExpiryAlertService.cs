﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.IO;
using System.Configuration;
using System.Windows.Forms;
using System.DirectoryServices;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Threading;
using System.Globalization;

namespace EvaluationDeadlineExpiryAlertService
{
    public partial class EvaluationDeadlineExpiryAlertService : ServiceBase
    {
        public EvaluationDeadlineExpiryAlertService()
        {
            InitializeComponent();
        }

        public static void Main()
        {
            EvaluationDeadlineExpiryAlertService srv = new EvaluationDeadlineExpiryAlertService();            
            srv.OnStart(null);
        }

        public Boolean AuthenticateUserEmailIDFromActiveDirectory(string userEmailId)
        {
            Boolean chkUserExist = false;
            try
            {
                DirectoryEntry deRoot = new DirectoryEntry("LDAP://RootDSE");
                string defaultNamingContext = null;
                if (deRoot != null)
                {
                    defaultNamingContext = deRoot.Properties["defaultNamingContext"].Value.ToString();
                }
                string filter = string.Format("(&(ObjectClass={0})(mail={1}))", "top", userEmailId);

                DirectoryEntry activeDirectoryaddress = new DirectoryEntry("LDAP://" + defaultNamingContext, null, null, AuthenticationTypes.Secure);
                DirectorySearcher searcher = new DirectorySearcher(activeDirectoryaddress);
                searcher.SearchScope = SearchScope.Subtree;

                searcher.Filter = filter;
                SearchResult result = searcher.FindOne();
                if (result != null)
                { 
                    chkUserExist = true;
                  
                }
            }
            catch (Exception ex)
            {
                WriteToLog("Error:"+userEmailId +" is not an Ashghal EmailID");
            }

            return chkUserExist;
        }

        string[] dtFormats = { "dd/MMM/yyyy", "yyyy/dd/MM", "MM/dd/yyyy", "MM/dd/yy", "M/d/yyyy", "dd/MM/yyyy", "dd/MM/yy" };
        DateTime dateTime = DateTime.Now;

        protected override void OnStart(string[] args)
        {
            SqlConnection sqlCn = null;
            try
            {
                MailMessage mailMessage = new MailMessage();

                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["From"].ToString());
                mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["To"].ToString()));
                mailMessage.Subject = "Test TCMS Alert: EvaluationDeadline Expiry Alert";
                mailMessage.IsBodyHtml = true;

                DateTime.TryParseExact(System.DateTime.Now.ToString().Split(' ')[0],
                                            dtFormats, CultureInfo.CurrentCulture, DateTimeStyles.None, out dateTime);
                mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'>sending the email notification for EvaluationDeadline Expiry Alert</i><br /><br />" +
                "<table style='width:80%' border='1'>" +
                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + dateTime.ToString().Split(' ')[0] + "</td></tr>" +
                "</table><br/><br/></body></html>";

                SmtpClient client = new SmtpClient();
                client.EnableSsl = true;
                //client.UseDefaultCredentials = true;
                client.Credentials = new System.Net.NetworkCredential(@"tcms", ConfigurationManager.AppSettings["emailPass"].ToString());
                ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                client.Send(mailMessage);

                string strConn = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
                using (sqlCn = new SqlConnection(strConn))
                {
                    sqlCn.Open();
                    DAL dal = new DAL();                    

                    DataTable dtEvalDeadLineExpFPWDNonManager = dal.GetDataFromDB("EvaluationDeadlineFPWDNonManager", "SELECT DISTINCT PROJECTS.tender_no, PROJECTS.project_code, PROJECTS.project_newname_en, " +
                    "CASE WHEN TenderDatesInfo.eval_com_sent2 IS NOT NULL THEN CONVERT(nvarchar, TenderDatesInfo.eval_com_sent2, 103) WHEN TenderDatesInfo.eval_com_sent1 IS NOT NULL THEN CONVERT(nvarchar, TenderDatesInfo.eval_com_sent1, 103) END AS finEvalSent, " +
                    " CASE WHEN (TenderDatesInfo.FPWD2 IS NOT NULL AND TenderDatesInfo.eval_com_sent2 IS NOT NULL) THEN TenderDatesInfo.FPWD2 WHEN (TenderDatesInfo.FPWD1 IS NOT NULL AND TenderDatesInfo.eval_com_sent1 IS NOT NULL) THEN TenderDatesInfo.FPWD1 END AS FPWD, USERS.email_address, USERS.actual_name, PROJECTS.proj_id, USERS.isheadOfSection " +
                    "FROM PROJECTS INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN Contacts ON PROJECTS.department_id = Contacts.department_id INNER JOIN " +
                    "EmailAlertRecipients ON EmailAlertRecipients.committee_id = PROJECTS.committee_id INNER JOIN USERS ON EmailAlertRecipients.user_id = USERS.user_id WHERE (TenderDatesInfo.stage_id = 3) AND (TenderDatesInfo.eval_com_sent1 IS NOT NULL) AND (TenderDatesInfo.eval_com_receive1 IS NULL) AND (TenderDatesInfo.FPWD1 IS NOT NULL)" +
                    " AND (PROJECTS.Tender_Status_id IN (3, 4, 5)) AND (PROJECTS.Tender_Status_id NOT IN (6,8, 11)) AND (USERS.isheadOfSection = 0) AND (EmailAlertRecipients.alert_cat_id = 6) OR " +
                    "(TenderDatesInfo.stage_id = 3) AND (TenderDatesInfo.eval_com_sent2 IS NOT NULL) AND (TenderDatesInfo.eval_com_receive2 IS NULL) AND (TenderDatesInfo.FPWD2 IS NOT NULL) AND (EmailAlertRecipients.alert_cat_id = 6) AND (PROJECTS.Tender_Status_id IN (3, 4, 5)) AND (PROJECTS.Tender_Status_id NOT IN (6,8, 11)) AND (USERS.isheadOfSection = 0 and USERS.isDeptManager = 0)", sqlCn);
                                         
                    DataTable dtEvalDeadLineExpFPWDManager = dal.GetDataFromDB("EvaluationDeadlineFPWDManager", "SELECT DISTINCT PROJECTS.tender_no, PROJECTS.project_code, PROJECTS.project_newname_en, " +
                    "CASE WHEN TenderDatesInfo.eval_com_sent2 IS NOT NULL THEN CONVERT(nvarchar, TenderDatesInfo.eval_com_sent2, 103) WHEN TenderDatesInfo.eval_com_sent1 IS NOT NULL THEN CONVERT(nvarchar, TenderDatesInfo.eval_com_sent1, 103) END AS finEvalSent, " +
                    " CASE WHEN (TenderDatesInfo.FPWD2 IS NOT NULL AND TenderDatesInfo.eval_com_sent2 IS NOT NULL) THEN TenderDatesInfo.FPWD2 WHEN (TenderDatesInfo.FPWD1 IS NOT NULL AND TenderDatesInfo.eval_com_sent1 IS NOT NULL) THEN TenderDatesInfo.FPWD1 END AS FPWD, USERS.email_address, USERS.actual_name, PROJECTS.proj_id, USERS.isheadOfSection " +
                    "FROM PROJECTS INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN Contacts ON PROJECTS.department_id = Contacts.department_id INNER JOIN " +
                    "EmailAlertRecipients ON EmailAlertRecipients.committee_id = PROJECTS.committee_id INNER JOIN USERS ON EmailAlertRecipients.user_id = USERS.user_id WHERE (TenderDatesInfo.stage_id = 3) AND (TenderDatesInfo.eval_com_sent1 IS NOT NULL) AND (TenderDatesInfo.eval_com_receive1 IS NULL) AND " +
                    "(TenderDatesInfo.FPWD1 IS NOT NULL) AND (EmailAlertRecipients.alert_cat_id = 6) AND (PROJECTS.Tender_Status_id IN (3, 4, 5)) AND (PROJECTS.Tender_Status_id NOT IN (6,8, 11)) AND (USERS.isheadOfSection = 1) OR " +
                    "(TenderDatesInfo.stage_id = 3) AND (TenderDatesInfo.eval_com_sent2 IS NOT NULL) AND (TenderDatesInfo.eval_com_receive2 IS NULL) AND (TenderDatesInfo.FPWD2 IS NOT NULL) AND (EmailAlertRecipients.alert_cat_id = 6) AND (PROJECTS.Tender_Status_id IN (3, 4, 5)) AND (PROJECTS.Tender_Status_id NOT IN (6,8, 11)) AND (USERS.isheadOfSection = 1)", sqlCn);                                              
                   

                    DataTable dtMergedFPWDRecords = new DataTable();
                    dtMergedFPWDRecords = dtEvalDeadLineExpFPWDNonManager; //.Select("isheadOfSection = false").CopyToDataTable()

                    foreach (DataRow dr in dtEvalDeadLineExpFPWDManager.Rows)
                    {
                        DataRow drMerged = dtMergedFPWDRecords.NewRow();                       
                        drMerged[0] = dr[0];  //TenderNo
                        drMerged[1] = dr[1];  //project_code
                        drMerged[2] = dr[2];  //project_newname_en
                        drMerged[3] = dr[3];  //finEvalSent
                        drMerged[4] = dr[4];  //FPWD1
                        drMerged[5] = dr[5];  //email_address
                        drMerged[6] = dr[6];  //actual_name       
                        drMerged[7] = dr[7];  //ProjId
                        drMerged[8] = dr[8];  //isheadOfSection                         
                        dtMergedFPWDRecords.Rows.Add(drMerged);
                        dtMergedFPWDRecords.AcceptChanges();
                    }


                    DataView dtView = new DataView(dtMergedFPWDRecords);
                    DataTable dtDistinctFPWDProjIds = dtView.ToTable(true, "proj_id");

                    CheckTotalDaysExceededAndSendEmail(dtDistinctFPWDProjIds, dtMergedFPWDRecords, sqlCn, "Financial Evaluation Report Submission's Proposed Date Is Expired");                   

                    DataTable dtEvalDeadLineExpTPWDNonManager = dal.GetDataFromDB("EvaluationDeadlineData", "SELECT distinct PROJECTS.tender_no, PROJECTS.project_code, PROJECTS.project_newname_en, CASE WHEN TenderDatesInfo.eval_tech_sent2 IS NOT NULL THEN CONVERT(nvarchar, TenderDatesInfo.eval_tech_sent2, 103) WHEN TenderDatesInfo.eval_tech_sent1 IS NOT NULL THEN CONVERT(nvarchar, TenderDatesInfo.eval_tech_sent1, 103) END AS techEvalSent, " +
                    " CASE WHEN (TenderDatesInfo.TPWD2 IS NOT NULL AND TenderDatesInfo.eval_tech_sent2 IS NOT NULL) THEN TenderDatesInfo.TPWD2 WHEN (TenderDatesInfo.TPWD1 IS NOT NULL AND TenderDatesInfo.eval_tech_sent1 IS NOT NULL) THEN TenderDatesInfo.TPWD1 END AS TPWD, USERS.email_address, USERS.actual_name," +
                    "PROJECTS.proj_id,USERS.isheadOfSection FROM PROJECTS INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN Contacts ON PROJECTS.department_id = Contacts.department_id INNER JOIN EmailAlertRecipients ON " +
                    "EmailAlertRecipients.committee_id = PROJECTS.committee_id INNER JOIN USERS ON EmailAlertRecipients.user_id = USERS.user_id WHERE (TenderDatesInfo.stage_id = 3) AND (TenderDatesInfo.eval_tech_sent1 IS NOT NULL) AND (TenderDatesInfo.eval_tech_receive1 IS NULL) AND (TenderDatesInfo.TPWD1 IS NOT NULL) AND (EmailAlertRecipients.alert_cat_id = 6) AND (PROJECTS.Tender_Status_id IN (3, 4, 5)) AND (PROJECTS.Tender_Status_id NOT IN (6,8, 11)) AND (USERS.isheadOfSection = 0) OR " +
                    "(TenderDatesInfo.stage_id = 3) AND (TenderDatesInfo.eval_tech_sent2 IS NOT NULL) AND (TenderDatesInfo.eval_tech_receive2 IS NULL) AND (TenderDatesInfo.TPWD2 IS NOT NULL) AND (EmailAlertRecipients.alert_cat_id = 6) AND (PROJECTS.Tender_Status_id IN (3, 4, 5)) AND (PROJECTS.Tender_Status_id NOT IN (6,8, 11)) AND (USERS.isheadOfSection = 0 and USERS.isDeptManager = 0)", sqlCn);
                                         
                    DataTable dtEvalDeadLineExpTPWDManager = dal.GetDataFromDB("EvaluationDeadlineData", "SELECT distinct PROJECTS.tender_no, PROJECTS.project_code, PROJECTS.project_newname_en, CASE WHEN TenderDatesInfo.eval_tech_sent2 IS NOT NULL THEN CONVERT(nvarchar, TenderDatesInfo.eval_tech_sent2, 103) WHEN TenderDatesInfo.eval_tech_sent1 IS NOT NULL THEN CONVERT(nvarchar, TenderDatesInfo.eval_tech_sent1, 103) END AS techEvalSent, " +
                    " CASE WHEN (TenderDatesInfo.TPWD2 IS NOT NULL AND TenderDatesInfo.eval_tech_sent2 IS NOT NULL) THEN TenderDatesInfo.TPWD2 WHEN (TenderDatesInfo.TPWD1 IS NOT NULL AND TenderDatesInfo.eval_tech_sent1 IS NOT NULL) THEN TenderDatesInfo.TPWD1 END AS TPWD, USERS.email_address, USERS.actual_name," +
                    "PROJECTS.proj_id,USERS.isheadOfSection FROM PROJECTS INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN Contacts ON PROJECTS.department_id = Contacts.department_id INNER JOIN EmailAlertRecipients ON " +
                    "EmailAlertRecipients.committee_id = PROJECTS.committee_id INNER JOIN USERS ON EmailAlertRecipients.user_id = USERS.user_id WHERE (TenderDatesInfo.stage_id = 3) AND (TenderDatesInfo.eval_tech_sent1 IS NOT NULL) AND (TenderDatesInfo.eval_tech_receive1 IS NULL) AND (TenderDatesInfo.TPWD1 IS NOT NULL) AND (EmailAlertRecipients.alert_cat_id = 6) AND (PROJECTS.Tender_Status_id IN (3, 4, 5)) AND (PROJECTS.Tender_Status_id NOT IN (6,8, 11)) AND (USERS.isheadOfSection = 1) OR " +
                    "(TenderDatesInfo.stage_id = 3) AND (TenderDatesInfo.eval_tech_sent2 IS NOT NULL) AND (TenderDatesInfo.eval_tech_receive2 IS NULL) AND (TenderDatesInfo.TPWD2 IS NOT NULL) AND (EmailAlertRecipients.alert_cat_id = 6) AND (PROJECTS.Tender_Status_id IN (3, 4, 5)) AND (PROJECTS.Tender_Status_id NOT IN (6,8, 11)) AND (USERS.isheadOfSection = 1)", sqlCn);

                    DataTable dtMergedTPWDRecords = new DataTable();                     
                    dtMergedTPWDRecords = dtEvalDeadLineExpTPWDNonManager; //.Select("isheadOfSection = false").CopyToDataTable();

                    foreach (DataRow dr in dtEvalDeadLineExpTPWDManager.Rows)
                    {
                        DataRow drMerged = dtMergedTPWDRecords.NewRow();
                        drMerged[0] = dr[0];  //TenderNo
                        drMerged[1] = dr[1];  //project_code
                        drMerged[2] = dr[2];  //project_newname_en
                        drMerged[3] = dr[3];  //finEvalSent
                        drMerged[4] = dr[4];  //FPWD1
                        drMerged[5] = dr[5];  //email_address
                        drMerged[6] = dr[6];  //actual_name       
                        drMerged[7] = dr[7];  //ProjId
                        drMerged[8] = dr[8];  //isheadOfSection                         
                        dtMergedTPWDRecords.Rows.Add(drMerged);
                        dtMergedTPWDRecords.AcceptChanges();
                    }

                    dtView = new DataView(dtMergedTPWDRecords);
                    DataTable dtDistinctTPWDProjIds = dtView.ToTable(true, "proj_id");                     
                    CheckTotalDaysExceededAndSendEmail(dtDistinctTPWDProjIds, dtMergedTPWDRecords, sqlCn, "Technical Evaluation Report Submission's Proposed Date Is Expired");

                }

                WriteToLog(DateTime.Now.ToString() + " Evaluation Deadline Expiry Alert Service has completed successfully.");                                  
            }
            catch (Exception ex)
            {
                WriteToLog(DateTime.Now.ToString()+" Exception occurred while processing Evaluation Deadline ExpiryAlertService. "+ex.Message);                 
            }
            finally
            {
                //sqlCn.Close();
            }
        }

        protected override void OnStop()
        {
        }

        MailMessage mailMessage = null;
        StringBuilder mailMessageBody = null;

        private void CheckTotalDaysExceededAndSendEmail(DataTable dtDistinctProjIds, DataTable dtMergedRecords, SqlConnection sqlCn, string emailSubject)
        {
            try
            { 
                SqlCommand sqlComm = null;                
                int rowCounter = 0;
                int totalDaysExceeded = 0;
                StringBuilder actualNames = new StringBuilder();
                StringBuilder toEmailIds = new StringBuilder();
                StringBuilder ccEmailIds = new StringBuilder();
                DataRow[] distinctToEmailIds = null;
                DataRow[] distinctCCEmailIds = null;
                mailMessage = new MailMessage();
                mailMessageBody = new StringBuilder();
                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["adminEmailID"].ToString());
                mailMessage.Subject = "TCMS Alert: Reminder - " + emailSubject; // +" - " + drOfSpecificProjIDs[0][0].ToString();
                mailMessage.IsBodyHtml = true;

                while (rowCounter < dtDistinctProjIds.Rows.Count)
                {
                    DataRow[] drOfSpecificProjIDs = dtMergedRecords.Select("proj_id='" + dtDistinctProjIds.Rows[rowCounter][0] + "'");
                    string dueDate = null;
                    DateTime.TryParseExact(drOfSpecificProjIDs[0][3].ToString().Split(' ')[0],
                                        dtFormats, CultureInfo.CurrentCulture, DateTimeStyles.None, out dateTime);
                    sqlComm = new SqlCommand("select Cal.CalendarDate As CalendarDate from (SELECT CalendarDate, ROW_NUMBER() OVER (ORDER BY CalendarDate) AS RowNumber FROM PWACalendar where CalendarDate > '" + dateTime.ToString().Split(' ')[0] + "' and CalendarDate<=GETDATE()-1 and Holiday = 0)Cal where Cal.RowNumber =" + drOfSpecificProjIDs[0][4].ToString(), sqlCn);
                    SqlDataReader sqlDtReader = sqlComm.ExecuteReader();
                    if (sqlDtReader.Read())
                    {
                        dueDate = sqlDtReader["CalendarDate"].ToString();
                        sqlDtReader.Close();

                        sqlComm = new SqlCommand("select Count(Cal.CalendarDate) As TotExceededDays from (SELECT CalendarDate, ROW_NUMBER() OVER (ORDER BY CalendarDate) AS RowNumber FROM PWACalendar where CalendarDate > '" + dueDate.ToString().Split(' ')[0] + "' and CalendarDate<=GETDATE()-1 and Holiday = 0)Cal", sqlCn);
                        sqlDtReader = sqlComm.ExecuteReader();
                        sqlDtReader.Read();
                        totalDaysExceeded = Convert.ToInt16(sqlDtReader["TotExceededDays"]);
                        sqlDtReader.Close();
                    }
                    else
                    {
                        totalDaysExceeded = -1;
                    }
                    sqlDtReader.Close();                

                    if (totalDaysExceeded >0)
                    {                      
                        DataView dtView = new DataView(drOfSpecificProjIDs.CopyToDataTable());
                        distinctToEmailIds = dtView.ToTable(true, "email_address", "actual_name", "proj_id", "isheadOfSection").Select("isheadOfSection='False' and proj_id='" + drOfSpecificProjIDs[0][7] + "'");
                        distinctCCEmailIds = dtView.ToTable(true, "email_address", "actual_name", "proj_id", "isheadOfSection").Select("isheadOfSection='True' and proj_id='" + drOfSpecificProjIDs[0][7] + "'");
                    
                        int emailRowCounter = 0;  
                        foreach (DataRow dr1 in distinctToEmailIds)
                        {
                            if (toEmailIds.ToString().IndexOf(dr1[0].ToString()) == -1)
                            {
                                toEmailIds.Append(dr1[0].ToString() + ";");                        
                            }                            
                        }

                        foreach (DataRow dr2 in distinctCCEmailIds)
                        {
                            if (actualNames.ToString().IndexOf(dr2[1].ToString()) == -1)
                            {
                                actualNames.Append(dr2[1].ToString());
                                actualNames.Append(",");
                            }
                            if (ccEmailIds.ToString().IndexOf(dr2[0].ToString()) == -1)
                            {
                                ccEmailIds.Append(dr2[0].ToString() + ";");
                            }
                            emailRowCounter++;                            
                        }

                        SendAlertAsEmail(drOfSpecificProjIDs[0][0].ToString(), drOfSpecificProjIDs[0][1].ToString(), drOfSpecificProjIDs[0][2].ToString(), emailSubject, drOfSpecificProjIDs[0][3].ToString(), Math.Abs(totalDaysExceeded), actualNames.ToString(), dueDate, toEmailIds.ToString(), ccEmailIds.ToString());                                                                                                                    
                    }
                     
                    rowCounter++;
                }
               
             }
             catch (Exception ex)
             {
                 WriteToLog(DateTime.Now + "::" + "Exception occurred " + ex.Message);
             }   
        }

        private void SendAlertAsEmail(string tenderNo, string projCode, string projName, string emailSubject, string sentDate, int totalExceededDays, string actualName, string dueDate, string toEmailIds, string ccEmailIds)
        {
            DateTime sendDateVal = DateTime.Now;
            DateTime.TryParseExact(sentDate.Split(' ')[0],
                                        dtFormats, CultureInfo.CurrentCulture, DateTimeStyles.None, out sendDateVal);

            DateTime dueDateVal = DateTime.Now;
            DateTime.TryParseExact(dueDate.Split(' ')[0],
                                        dtFormats, CultureInfo.CurrentCulture, DateTimeStyles.None, out dueDateVal);

            if (mailMessageBody.Length == 0)
            {
                mailMessageBody.Append("<html><body><div style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</div><br/><br/><div style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</div><br/><br/><div style='font-family:Calibri; font-size:15'>" +
                "Tender Committee here by remind you to send the following report at your earliest as the evaluation days exceeds (" + totalExceededDays + ") working days.</div><br /><br />" +
                "<table style='width:80%' border='0'><tr><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:#0070C0'><b>Tender No.</b></td><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15; color:#0070C0'>" + tenderNo + "</td></tr>" +
                "<tr><td style='font-family:Calibri; font-size:15;color:#0070C0'><b>Project ID</b></td><td style='font-family:Calibri; font-size:15;color:#0070C0'>" + projCode + "</td></tr><tr><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:#0070C0'>" +
                "<b>Project Title</b></td><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:#0070C0'>" + projName + "</td></tr><tr><td style='font-family:Calibri; font-size:15;color:#0070C0'><b>Subject</b></td><td style='font-family:Calibri; font-size:15;color:#0070C0'>" + emailSubject.Split(' ')[0] + " " + emailSubject.Split(' ')[1] + " Report</td>" +
                "</tr><tr><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:#0070C0'><b>Send To</b></td><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:#0070C0'>" + actualName + "</td></tr><tr><td style='font-family:Calibri; font-size:15;color:#0070C0'>" +
                "<b>Date of Request</b></td><td style='font-family:Calibri; font-size:15;color:#0070C0'>" + Convert.ToDateTime(sendDateVal).ToString("dd/MMM/yyyy") + "</td></tr><tr><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:Red'><b>Due Date</b></td><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:Red'>" +
                Convert.ToDateTime(dueDateVal).ToString("dd/MMM/yyyy") + "</td></tr><tr><td style='font-family:Calibri; font-size:15;color:#0070C0'><b>Status</b></td><td style='font-family:Calibri; font-size:15; color: #0070C0;'>Pending with Department for (" + emailSubject.Split(' ')[0] + " " + emailSubject.Split(' ')[1] + " Report)</td></tr></table><br/><br/></body></html>");
            }
            else
            {
                mailMessageBody.Append("<br/><br/><html><body><div style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</div><br/><br/><div style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</div><br/><br/><div style='font-family:Calibri; font-size:15'>" +
                "Tender Committee here by remind you to send the following report at your earliest as the evaluation days exceeds (" + totalExceededDays + ") working days.</div><br /><br />" +
                "<table style='width:80%' border='0'><tr><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:#0070C0'><b>Tender No.</b></td><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15; color:#0070C0'>" + tenderNo + "</td></tr>" +
                "<tr><td style='font-family:Calibri; font-size:15;color:#0070C0'><b>Project ID</b></td><td style='font-family:Calibri; font-size:15;color:#0070C0'>" + projCode + "</td></tr><tr><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:#0070C0'>" +
                "<b>Project Title</b></td><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:#0070C0'>" + projName + "</td></tr><tr><td style='font-family:Calibri; font-size:15;color:#0070C0'><b>Subject</b></td><td style='font-family:Calibri; font-size:15;color:#0070C0'>" + emailSubject.Split(' ')[0] + " " + emailSubject.Split(' ')[1] + " Report</td>" +
                "</tr><tr><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:#0070C0'><b>Send To</b></td><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:#0070C0'>" + actualName + "</td></tr><tr><td style='font-family:Calibri; font-size:15;color:#0070C0'>" +
                "<b>Date of Request</b></td><td style='font-family:Calibri; font-size:15;color:#0070C0'>" + Convert.ToDateTime(sendDateVal).ToString("dd/MMM/yyyy") + "</td></tr><tr><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:Red'><b>Due Date</b></td><td style='background-color:#D2EAF1;font-family:Calibri; font-size:15;color:Red'>" +
                Convert.ToDateTime(dueDateVal).ToString("dd/MMM/yyyy") + "</td></tr><tr><td style='font-family:Calibri; font-size:15;color:#0070C0'><b>Status</b></td><td style='font-family:Calibri; font-size:15; color: #0070C0;'>Pending with Department for (" + emailSubject.Split(' ')[0] + " " + emailSubject.Split(' ')[1] + " Report)</td></tr></table><br/><br/></body></html>");
            }

            mailMessage.To.Clear();
            mailMessage.CC.Clear();

            mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["adminEmailID"].ToString());
            foreach (var address in toEmailIds.ToString().Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
            {
                mailMessage.To.Add(address);                 
            }

            foreach (var address in ccEmailIds.ToString().Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
            {
                mailMessage.CC.Add(address);
            }

            if (mailMessage.To.Count == 0)
            {
                mailMessage.To.Add(ConfigurationManager.AppSettings["From"].ToString());
                mailMessage.To.Add(ConfigurationManager.AppSettings["To"].ToString());
            }

            SmtpClient client = new SmtpClient();
            client.EnableSsl = true;
            mailMessage.Body = mailMessageBody.ToString();
            client.Credentials = new System.Net.NetworkCredential(@"tcms", ConfigurationManager.AppSettings["emailPass"].ToString());
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
            client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
            client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
            client.Send(mailMessage);
        }

        void WriteToLog(string errMsg)
        {
            FileStream fileStreamObj = null;
            StreamWriter streamWriterObj = null;
            string strFileName = ConfigurationManager.AppSettings["LogFile"];
            bool boolFlag = File.Exists(strFileName);

            if (boolFlag)
                fileStreamObj = new FileStream(strFileName, FileMode.Append, FileAccess.Write);
            else
                fileStreamObj = new FileStream(strFileName, FileMode.OpenOrCreate, FileAccess.Write);

            streamWriterObj = new StreamWriter(fileStreamObj);
            
            streamWriterObj.WriteLine(errMsg);
            streamWriterObj.WriteLine(streamWriterObj.NewLine);
         
            streamWriterObj.Close();         
            fileStreamObj.Close();

        }
    }
}
