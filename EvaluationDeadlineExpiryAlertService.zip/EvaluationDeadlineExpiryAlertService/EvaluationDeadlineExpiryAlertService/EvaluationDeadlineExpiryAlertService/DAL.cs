﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace EvaluationDeadlineExpiryAlertService
{
    class DAL
    {                 

        public DataTable GetDataFromDB(string dataTabName, string sqlQuery, SqlConnection sqlConn)
        {
            SqlDataAdapter da = null;
            DataTable table = null;
            try
            {
                table = new DataTable(dataTabName);                
                da = new SqlDataAdapter(@sqlQuery, sqlConn);
                da.Fill(table);
            }
            catch (Exception ex)
            {
                return null;
            }
            return table;
        }
    }
}
